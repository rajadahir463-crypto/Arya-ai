# ARYA AI — Android + Backend + Website Starter

یہ ARYA کا **ابتدائی قابلِ توسیع سورس پروجیکٹ** ہے، مکمل Ultimate AI نہیں۔ اس میں:
- Android ایپ: Kotlin + Jetpack Compose
- FastAPI backend: OpenAI-compatible AI API سے رابطہ
- سادہ ARYA landing website
- GitHub Actions workflow: Cloud میں Android Debug APK بنانا

## 1) فون سے Cloud پر کام شروع کریں

1. https://github.com پر اکاؤنٹ بنائیں یا سائن اِن کریں۔
2. نیا repository بنائیں، نام `arya-ai` رکھیں۔
3. اس ZIP کو extract کریں اور اس کے اندر موجود تمام فائلیں repository میں upload کریں۔
4. GitHub repository میں **Code → Codespaces → Create codespace on main** منتخب کریں۔
5. Codespaces براؤزر میں VS Code جیسا ایڈیٹر کھول دے گا۔ Android APK بنانے کے لیے GitHub Actions استعمال ہوگا۔

Codespaces: https://github.com/codespaces

## 2) APK Cloud میں بنائیں

1. تمام فائلیں GitHub پر upload/commit کریں۔
2. Repository کے **Actions** tab میں جائیں۔
3. `Build Android Debug APK` workflow چلائیں (یا نئی commit کے بعد خود چلے گا)۔
4. کامیاب build کے بعد workflow run کھولیں۔
5. نیچے **Artifacts** میں `arya-debug-apk` ڈاؤن لوڈ کریں۔
6. ZIP کھول کر `app-debug.apk` اپنے Android فون پر install کریں۔

یہ Debug APK صرف ٹیسٹنگ کے لیے ہے۔ عوامی ریلیز کے لیے اپنی signing key اور release workflow بنانا ہوگا۔

## 3) AI Backend چلائیں

`backend` فولڈر میں `.env.example` کو `.env` بنائیں اور اپنی AI provider کی API key اور OpenAI-compatible endpoint درج کریں۔

مثال:
```
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=اپنی_اصل_کلید
AI_MODEL=اپنے_اکاؤنٹ_کا_دستیاب_ماڈل
```

پھر backend کو کسی Python hosting سروس پر deploy کریں۔ API key کبھی Android ایپ یا GitHub repository میں نہ رکھیں۔

Backend endpoints:
- `GET /health`
- `POST /chat` — JSON: `{"message":"سلام"}`

Deploy کے بعد اپنی backend URL کو Android ایپ میں درج کریں۔ ایپ میں Settings کے ذریعے Base URL تبدیل کیا جا سکتا ہے۔

## 4) Website

`website/index.html` ایک ابتدائی landing page ہے۔ اسے GitHub Pages یا Vercel پر deploy کیا جا سکتا ہے:
- Vercel: https://vercel.com/new
- GitHub Pages docs: https://docs.github.com/pages

Vercel پر `website` فولڈر کو static site کے طور پر deploy کریں، یا اسے الگ repository میں رکھیں۔

## 5) ابھی کیا کام کرتا ہے؟

- Android پر ARYA چیٹ انٹرفیس
- Backend سے حقیقی AI جواب، بشرطیکہ backend deploy ہو اور API key/model درست ہو
- Website کا ابتدائی صفحہ
- GitHub Actions کے ذریعے Debug APK build

## 6) ابھی کیا شامل نہیں؟

Voice streaming، memory database، autonomous agents، image/video generation، account system، payments اور production-grade security ابھی اگلے مراحل ہیں۔ انہیں مرحلہ وار شامل کیا جائے گا۔ کسی فیچر کو فعال ظاہر نہیں کیا گیا جب تک اس کا اصل انضمام نہ ہو۔

## اہم سیکیورٹی
- API key صرف backend کے secret/environment variable میں رکھیں۔
- `.env` فائل GitHub پر upload نہ کریں۔
- Debug APK عوامی تقسیم کے لیے نہیں۔
- کسی بھی خودکار موبائل عمل سے پہلے واضح user permission ضروری ہوگی۔
