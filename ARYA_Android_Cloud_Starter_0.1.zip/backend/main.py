import os
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="ARYA AI API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)

@app.get("/health")
async def health():
    return {"status": "ok", "service": "arya-api"}

@app.post("/chat")
async def chat(payload: ChatRequest):
    base = os.getenv("AI_BASE_URL", "").rstrip("/")
    key = os.getenv("AI_API_KEY", "")
    model = os.getenv("AI_MODEL", "")
    if not base or not key or key == "replace_me" or not model:
        raise HTTPException(
            status_code=503,
            detail="Backend configuration missing. Set AI_BASE_URL, AI_API_KEY and AI_MODEL."
        )

    url = f"{base}/chat/completions"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You are ARYA, a helpful, honest AI assistant. Reply in the user's language."},
            {"role": "user", "content": payload.message}
        ],
        "temperature": 0.7
    }
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(url, headers=headers, json=body)
            response.raise_for_status()
            data = response.json()
            reply = data["choices"][0]["message"]["content"]
            return {"reply": reply}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"AI provider returned HTTP {exc.response.status_code}")
    except (httpx.HTTPError, KeyError, IndexError, TypeError):
        raise HTTPException(status_code=502, detail="Could not get a valid response from the AI provider.")
