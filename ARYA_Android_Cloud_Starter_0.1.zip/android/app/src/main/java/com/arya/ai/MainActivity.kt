package com.arya.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF080D19)
private val Panel = Color(0xFF121C2E)
private val Blue = Color(0xFF42A5FF)
private val White = Color(0xFFF3F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AryaApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun AryaApp() {
    var apiBase by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("السلام علیکم! میں ARYA ہوں۔ Backend URL سیٹ کرکے مجھ سے بات شروع کریں۔", false)
        )
    }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = White, onSurface = White
    )) {
        Column(
            Modifier.fillMaxSize().background(Navy).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).background(Blue.copy(alpha = .16f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("A", color = Blue, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ARYA AI", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Your AI assistant · Starter 0.1", color = Blue, fontSize = 11.sp)
                }
                Text("ONLINE", color = Color(0xFF68D391), fontSize = 10.sp)
            }

            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = apiBase,
                onValueChange = { apiBase = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Backend URL (مثلاً https://your-api.example.com)") },
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (msg.fromUser) Color(0xFF173A61) else Panel,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(msg.text, Modifier.padding(13.dp), color = White, fontSize = 14.sp)
                        }
                    }
                }
                if (busy) item { Text("ARYA جواب تیار کر رہا ہے…", color = Blue) }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("ARYA سے کچھ پوچھیں…") },
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    enabled = input.isNotBlank() && !busy,
                    onClick = {
                        val question = input.trim()
                        val base = apiBase.trim().trimEnd('/')
                        if (base.isBlank() || base.contains("YOUR-BACKEND")) {
                            messages.add(ChatMessage("پہلے اوپر اپنا deployed Backend URL درج کریں۔", false))
                        } else {
                            messages.add(ChatMessage(question, true))
                            input = ""
                            busy = true
                            scope.launch {
                                val answer = withContext(Dispatchers.IO) {
                                    askArya(base, question)
                                }
                                messages.add(ChatMessage(answer, false))
                                busy = false
                            }
                        }
                    }
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Blue)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("ابتدائی ورژن · AI جواب کے لیے Backend اور API Key ضروری ہیں",
                color = Color.LightGray, fontSize = 10.sp)
        }
    }
}

private fun askArya(base: String, message: String): String {
    return try {
        val client = OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .build()
        val json = JSONObject().put("message", message).toString()
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url("$base/chat").post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) "Backend error ${response.code}: ${raw.take(400)}"
            else JSONObject(raw).optString("reply", "Backend نے خالی جواب دیا۔")
        }
    } catch (e: Exception) {
        "کنکشن مکمل نہیں ہوا: ${e.message ?: "نامعلوم خرابی"}"
    }
}
